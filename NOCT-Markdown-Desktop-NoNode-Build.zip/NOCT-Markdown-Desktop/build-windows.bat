@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo =========================================
echo   NOCT Markdown Viewer - Windows Build

echo =========================================
echo.
where node >nul 2>&1
if errorlevel 1 goto :nonode
where npm >nul 2>&1
if errorlevel 1 goto :nonode

echo [1/3] Installing build dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 goto :error

echo.
echo [2/3] Preparing offline libraries...
call npm run prepare:assets
if errorlevel 1 goto :error

echo.
echo [3/3] Building both Windows EXEs...
call npm run build:win
if errorlevel 1 goto :error

echo.
echo SUCCESS: See the dist folder for both files.
start "" "%~dp0dist"
pause
exit /b 0

:nonode
echo ERROR: Install Node.js LTS from https://nodejs.org/ first.
pause
exit /b 1

:error
echo ERROR: Build failed. Check the error message above.
pause
exit /b 1
