@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo =====================================================
echo NOCT Markdown Viewer - EXE Build Without Node Install
echo =====================================================
echo.
echo This script temporarily downloads a portable Node.js runtime.
echo Node.js is NOT installed on your PC, and will be deleted afterward.
echo An Internet connection is needed during the build.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build-no-install-node.ps1"
set EXITCODE=%ERRORLEVEL%
echo.
if not "%EXITCODE%"=="0" (
  echo BUILD FAILED. See the error above.
) else (
  echo BUILD COMPLETE. Your EXE files are in the dist folder.
)
pause
exit /b %EXITCODE%
