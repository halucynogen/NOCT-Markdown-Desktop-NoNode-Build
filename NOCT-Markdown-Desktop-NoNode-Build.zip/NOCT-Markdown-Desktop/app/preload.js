'use strict';

const { contextBridge, ipcRenderer } = require('electron');

// Only two narrowly scoped actions are exposed to untrusted Markdown content.
// No filesystem or Node.js API is made available in the viewer.
contextBridge.exposeInMainWorld('noctDesktop', {
  openExternal: (url) => ipcRenderer.invoke('noct:open-external', url),
  savePdf: (filename) => ipcRenderer.invoke('noct:save-pdf', filename)
});
