'use strict';

// NOCT Markdown Desktop -- Electron main process.
// The viewer itself runs as an isolated local page; no renderer Node.js access.
const { app, BrowserWindow, Menu, dialog, ipcMain, shell } = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const APP_ID = 'com.noct.markdownviewer';
let mainWindow = null;

function isAllowedExternalUrl(value) {
  if (typeof value !== 'string' || value.length > 8192) return false;
  try {
    const url = new URL(value);
    return ['http:', 'https:', 'mailto:'].includes(url.protocol);
  } catch {
    return false;
  }
}

async function openExternalUrl(value) {
  if (!isAllowedExternalUrl(value)) {
    return { ok: false, error: '허용되지 않은 링크 형식입니다.' };
  }
  try {
    await shell.openExternal(value);
    return { ok: true };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

function isMainWindowSender(event) {
  return Boolean(mainWindow && !mainWindow.isDestroyed() && event.sender === mainWindow.webContents);
}

function safePdfName(input) {
  const name = typeof input === 'string' ? path.parse(input).name : 'NOCT-Document';
  return (name.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 100) || 'NOCT-Document') + '.pdf';
}

ipcMain.handle('noct:open-external', async (event, url) => {
  if (!isMainWindowSender(event)) return { ok: false, error: '요청을 확인할 수 없습니다.' };
  return openExternalUrl(url);
});

ipcMain.handle('noct:save-pdf', async (event, documentName) => {
  if (!isMainWindowSender(event)) return { saved: false, error: '요청을 확인할 수 없습니다.' };
  try {
    const defaultPath = path.join(app.getPath('documents'), safePdfName(documentName));
    const choice = await dialog.showSaveDialog(mainWindow, {
      title: 'NOCT — PDF 저장',
      defaultPath,
      filters: [{ name: 'PDF 파일', extensions: ['pdf'] }],
      properties: ['showOverwriteConfirmation']
    });
    if (choice.canceled || !choice.filePath) return { saved: false, canceled: true };
    const pdf = await event.sender.printToPDF({
      printBackground: true,
      pageSize: 'A4',
      preferCSSPageSize: true,
      displayHeaderFooter: false
    });
    await fs.writeFile(choice.filePath, pdf);
    return { saved: true, path: choice.filePath };
  } catch (error) {
    return { saved: false, error: String(error?.message || error) };
  }
});

function createWindow() {
  mainWindow = new BrowserWindow({
    title: 'NOCT Markdown Viewer',
    width: 1350,
    height: 880,
    minWidth: 800,
    minHeight: 550,
    backgroundColor: '#101311',
    show: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      webviewTag: false,
      allowRunningInsecureContent: false
    }
  });

  const initialUrl = pathToFileURL(path.join(__dirname, 'index.html')).toString();

  // Do not let markdown links navigate the actual app window. Internet links
  // are always handed to the Windows default browser after protocol filtering.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    void openExternalUrl(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, destination) => {
    if (destination !== initialUrl) {
      event.preventDefault();
      void openExternalUrl(destination);
    }
  });

  mainWindow.once('ready-to-show', () => mainWindow?.show());
  void mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(() => {
  if (process.platform === 'win32') app.setAppUserModelId(APP_ID);
  Menu.setApplicationMenu(null);
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
