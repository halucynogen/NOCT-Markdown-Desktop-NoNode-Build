window.addEventListener('DOMContentLoaded',()=>{
'use strict';

const $=id=>document.getElementById(id);

const docs=new Map();
const assets=new Map();
const objectURLs=new Map();

let current=null;
let raw='';
let loadVersion=0;
let font=17;
let hits=[];
let hitIndex=-1;
let searchTimer;
let dragCount=0;

const mdPattern=/\.(md|markdown|mdown|txt)$/i;
const imgPattern=/\.(png|jpe?g|gif|webp|svg|avif|bmp|ico)$/i;

const escape=s=>String(s).replace(/[&<>"']/g,c=>
 ({
  '&':'&amp;',
  '<':'&lt;',
  '>':'&gt;',
  '"':'&quot;',
  "'":'&#39;'
 }[c])
);

const tell=s=>$('status').textContent=s;

const setDisabled=flag=>{
 $('pdf').disabled=flag;
 $('download').disabled=flag;
};

function normalize(p){
 const out=[];

 for(const part of p.replace(/\\/g,'/').split('/')){
  if(!part||part==='.')continue;
  if(part==='..')out.pop();
  else out.push(part);
 }

 return out.join('/');
}

function decodePath(p){
 try{return decodeURIComponent(p);}
 catch{return p;}
}

function directory(p){
 return p.includes('/')?p.slice(0,p.lastIndexOf('/')+1):'';
}

function assetURL(key){
 if(!objectURLs.has(key)){
  objectURLs.set(key,URL.createObjectURL(assets.get(key)));
 }

 return objectURLs.get(key);
}

function resolveKey(url,map){
 const clean=decodePath(url.split(/[?#]/)[0]);

 const relative=normalize(
  directory(current?.key||'')+clean
 );

 if(map.has(relative))return relative;

 const direct=normalize(clean);
 if(map.has(direct))return direct;

 const candidates=[...map.keys()].filter(k=>
  k===direct||k.endsWith('/'+direct)
 );

 return candidates.length===1?candidates[0]:null;
}

function showView(view){
 document.body.dataset.view=view;
 $('sourcePane').hidden=view==='preview';
 $('preview').hidden=view==='source';

 document.querySelectorAll('button[data-view]').forEach(el=>{
  el.classList.toggle('active',el.dataset.view===view);
 });
}

function fileList(){
 $('files').replaceChildren();
 $('fileCount').textContent=String(docs.size).padStart(2,'0');

 for(const [key,file] of docs){
  const b=document.createElement('button');

  b.className='file-row'+(
   current?.key===key?' selected':''
  );

  b.textContent=file.name;
  b.title=key;
  b.onclick=()=>openDocument(key);

  $('files').append(b);
 }
}

async function importFiles(list){
 const incoming=Array.from(list);
 let first=null;

 for(const file of incoming){
  const key=normalize(
   file.webkitRelativePath||file.name
  );

  if(mdPattern.test(file.name)){
   if(file.size>5*1024*1024){
    tell('5MB를 넘는 문서는 제외했습니다: '+file.name);
    continue;
   }

   docs.set(key,file);
   first??=key;

  }else if(
   file.type.startsWith('image/')||
   imgPattern.test(file.name)
  ){
   if(objectURLs.has(key)){
    URL.revokeObjectURL(objectURLs.get(key));
    objectURLs.delete(key);
   }

   assets.set(key,file);
  }
 }

 fileList();

 if(first){
  await openDocument(first);
 }else if(current){
  renderDocument();
 }else{
  tell(
   '마크다운 문서를 선택해 주세요. 이미지 '+
   assets.size+'개를 연결했습니다.'
  );
 }
}

async function openDocument(key){
 const file=docs.get(key);
 if(!file)return;

 const version=++loadVersion;
 tell('문서를 읽는 중…');

 try{
  const buffer=await file.arrayBuffer();
  if(version!==loadVersion)return;

  raw=new TextDecoder(
   $('encoding').value,
   {ignoreBOM:true}
  ).decode(buffer);

  current={key,file};

  $('source').value=raw;
  $('title').textContent=file.name;

  $('meta').textContent=
   (file.size/1024).toFixed(1)+' KB · '+
   raw.split(/\r\n|\r|\n/).length.toLocaleString()+
   '줄 · '+key;

  document.title=file.name+' — NOCT';

  fileList();
  renderDocument();

  $('preview').scrollTop=0;
  $('source').scrollTop=0;

 }catch{
  if(version===loadVersion){
   tell('파일을 읽지 못했습니다. 다시 선택해 주세요.');
  }
 }
}

function installMath(){
 marked.use({
  extensions:[
   {
    name:'noctMathBlock',
    level:'block',

    start:s=>s.indexOf('$$'),

    tokenizer(s){
     const m=/^ {0,3}\$\$([\s\S]+?)\$\$[ \t]*(?:\n|$)/.exec(s);

     if(m){
      return{
       type:'noctMathBlock',
       raw:m[0],
       text:m[1].trim()
      };
     }
    },

    renderer:t=>
     '<div class="math math-display">'+
     escape(t.text)+'</div>\n'
   },

   {
    name:'noctMathInline',
    level:'inline',

    start:s=>{
     const indexes=[
      s.indexOf('$'),
      s.indexOf('\\(')
     ].filter(n=>n>=0);

     return indexes.length?
      Math.min(...indexes):undefined;
    },

    tokenizer(s){
     const m=
      /^\\\(([\s\S]+?)\\\)/.exec(s)||
      /^\$([^$\n]+?)\$(?!\$)/.exec(s);

     if(m){
      return{
       type:'noctMathInline',
       raw:m[0],
       text:m[1]
      };
     }
    },

    renderer:t=>
     '<span class="math">'+escape(t.text)+'</span>'
   }
  ]
 });
}

function renderDocument(){
 if(!current)return;

 if(!window.marked||!window.DOMPurify){
  setDisabled(true);
  showView('source');

  tell(
   '미리보기 도구를 불러오지 못했습니다. '+
   '인터넷 연결 후 새로고침해 주세요.'
  );

  return;
 }

 try{
  const html=marked.parse(
   raw.replace(/^\uFEFF/,''),
   {gfm:true,breaks:false}
  );

  const safe=DOMPurify.sanitize(html,{
   USE_PROFILES:{html:true},

   FORBID_TAGS:[
    'style','script','iframe','object','embed',
    'form','input','button','textarea','select',
    'video','audio','source','link','meta'
   ],

   FORBID_ATTR:[
    'style','srcset','id','name','autofocus'
   ]
  });

  const template=document.createElement('template');
  template.innerHTML=safe;

  for(const image of template.content.querySelectorAll('img')){
   const source=image.getAttribute('src')||'';

   image.removeAttribute('src');
   image.referrerPolicy='no-referrer';
   image.loading='eager';

   const key=resolveKey(source,assets);
   let url=key?assetURL(key):null;

   if(!url&&/^https?:\/\//i.test(source)){
    url=source;
   }

   if(!url&&/^\/\//.test(source)){
    url='https:'+source;
   }

   if(
    !url&&
    /^data:image\/(?:png|jpeg|gif|webp|avif|bmp);base64,/i.test(source)
   ){
    url=source;
   }

   if(url){
    image.src=url;
    image.dataset.original=source;

    image.addEventListener(
     'error',
     ()=>missingImage(image,source),
     {once:true}
    );

    image.addEventListener('click',()=>{
     $('largeImage').src=image.src;
     $('largeImage').alt=image.alt||'확대 이미지';
     $('lightbox').showModal();
    });

   }else{
    missingImage(image,source);
   }
  }

  $('document').replaceChildren(template.content);

  for(const math of $('document').querySelectorAll('.math')){
   if(window.katex){
    katex.render(math.textContent,math,{
     displayMode:math.classList.contains('math-display'),
     throwOnError:false,
     trust:false,
     strict:'ignore'
    });
   }
  }

  for(const table of $('document').querySelectorAll('table')){
   const wrap=document.createElement('div');

   wrap.className='table-wrap';
   table.before(wrap);
   wrap.append(table);
  }

  for(const pre of $('document').querySelectorAll('pre')){
   const b=document.createElement('button');

   b.className='copy-code';
   b.textContent='코드 복사';

   b.onclick=()=>copyText(
    pre.querySelector('code')?.textContent||'',
    b
   );

   pre.append(b);
  }

  for(const a of $('document').querySelectorAll('a')){
   const href=a.getAttribute('href')||'';

   if(
    /^https?:\/\//i.test(href)||
    /^mailto:/i.test(href)
   ){
    // 원격 이미지 이외의 온라인 링크(PDF, ZIP 등)는 기본 브라우저로 연다.
    a.target='_blank';
    a.rel='noopener noreferrer';
    if(window.noctDesktop){
     a.onclick=async e=>{
      e.preventDefault();
      const result=await window.noctDesktop.openExternal(href);
      if(!result?.ok){
       tell('외부 링크를 열 수 없습니다: '+(result?.error||href));
      }
     };
    }

   }else{
    a.onclick=e=>{
     e.preventDefault();

     if(href.startsWith('#')){
      const id=decodePath(href.slice(1));

      const target=[
       ...$('document').querySelectorAll('[id]')
      ].find(el=>el.id===id);

      if(target){
       showView('preview');
       target.scrollIntoView({block:'start'});
      }else{
       tell('해당 제목을 찾지 못했습니다.');
      }

     }else{
      const key=resolveKey(href,docs);

      if(key){
       openDocument(key);
      }else{
       tell(
        '연결된 문서가 없습니다. '+
        '문서 폴더를 열어 주세요.'
       );
      }
     }
    };
   }
  }

  buildTOC();
  setDisabled(false);

  if(!$('searchbar').hidden)search();

  tell(
   '문서를 열었습니다. '+
   '이미지가 누락되면 폴더 열기로 연결해 주세요.'
  );

 }catch{
  setDisabled(true);
  showView('source');
  tell('미리보기를 만들지 못했습니다. 원문으로 표시합니다.');
 }
}

function missingImage(image,source){
 const note=document.createElement('div');

 note.className='image-missing';

 note.textContent=
  '이미지를 불러오지 못했습니다: '+
  (image.alt||source||'경로 없음')+
  ' · 폴더 또는 이미지 파일을 함께 열어 주세요.';

 image.replaceWith(note);
}

function buildTOC(){
 $('toc').replaceChildren();
 const used=new Map();

 for(const h of $('document').querySelectorAll('h1,h2,h3,h4')){
  const base=
   h.textContent.trim().toLowerCase()
    .replace(/[^\p{L}\p{N}_\s-]/gu,'')
    .replace(/\s/g,'-')||'section';

  const count=used.get(base)||0;
  used.set(base,count+1);

  h.id=base+(count?'-'+count:'');

  const b=document.createElement('button');

  b.className='toc-row';
  b.textContent=h.textContent;
  b.title=h.textContent;

  b.style.paddingLeft=
   (10+(Number(h.tagName[1])-1)*10)+'px';

  b.onclick=()=>{
   if(document.body.dataset.view==='source'){
    showView('preview');
   }

   h.scrollIntoView({
    behavior:'smooth',
    block:'start'
   });
  };

  $('toc').append(b);
 }
}

async function copyText(text,button){
 try{
  await navigator.clipboard.writeText(text);

  const old=button?.textContent;

  if(button){
   button.textContent='복사됨';

   setTimeout(()=>{
    button.textContent=old;
   },1200);
  }

  tell('클립보드에 복사했습니다.');

 }catch{
  $('source').value=text;
  showView('source');

  $('source').focus();
  $('source').select();

  tell(
   '복사가 제한되어 텍스트를 선택했습니다. '+
   'Ctrl+C를 누르세요.'
  );
 }
}

function clearMarks(){
 for(const m of $('document').querySelectorAll('mark[data-search]')){
  m.replaceWith(document.createTextNode(m.textContent));
 }

 $('document').normalize();
 hits=[];
 hitIndex=-1;
}

function search(){
 clearMarks();

 const query=$('query').value;

 if(!query){
  $('matches').textContent='0 / 0';
  return;
 }

 if(document.body.dataset.view==='source'){
  showView('preview');
 }

 const walker=document.createTreeWalker(
  $('document'),
  NodeFilter.SHOW_TEXT,
  {
   acceptNode(node){
    return node.parentElement.closest(
     '.katex,button,script,style'
    )
     ?NodeFilter.FILTER_REJECT
     :NodeFilter.FILTER_ACCEPT;
   }
  }
 );

 const nodes=[];

 while(walker.nextNode()){
  nodes.push(walker.currentNode);
 }

 const needle=query.toLocaleLowerCase();

 for(const node of nodes){
  const value=node.nodeValue;
  const lower=value.toLocaleLowerCase();

  let pos=0;
  let index=lower.indexOf(needle);
  let fragment=null;

  while(index!==-1){
   if(!fragment){
    fragment=document.createDocumentFragment();
   }

   fragment.append(
    document.createTextNode(value.slice(pos,index))
   );

   const mark=document.createElement('mark');

   mark.dataset.search='';
   mark.textContent=value.slice(index,index+query.length);

   fragment.append(mark);
   hits.push(mark);

   pos=index+query.length;
   index=lower.indexOf(needle,pos);
  }

  if(fragment){
   fragment.append(
    document.createTextNode(value.slice(pos))
   );

   node.replaceWith(fragment);
  }
 }

 moveMatch(1);
}

function moveMatch(direction){
 if(!hits.length){
  $('matches').textContent='0 / 0';
  return;
 }

 if(hitIndex>=0){
  hits[hitIndex].classList.remove('current');
 }

 hitIndex=(hitIndex+direction+hits.length)%hits.length;

 hits[hitIndex].classList.add('current');

 hits[hitIndex].scrollIntoView({
  block:'center',
  behavior:'smooth'
 });

 $('matches').textContent=
  (hitIndex+1)+' / '+hits.length;
}

function toggleSearch(open){
 $('searchbar').hidden=!open;

 if(open){
  $('query').focus();
  $('query').select();
 }else{
  clearMarks();
  $('query').value='';
 }
}

async function exportPDF(){
 if(!current)return;

 tell('이미지와 글꼴을 준비하는 중…');
 $('pdf').disabled=true;

 try{
  const images=[
   ...$('document').querySelectorAll('img')
  ];

  await Promise.race([
   Promise.all(images.map(img=>
    img.complete
     ?Promise.resolve()
     :new Promise(resolve=>{
       img.addEventListener(
        'load',resolve,{once:true}
       );
       img.addEventListener(
        'error',resolve,{once:true}
       );
      })
   )),

   new Promise(resolve=>setTimeout(resolve,8000))
  ]);

  if(document.fonts){
   await Promise.race([
    document.fonts.ready,
    new Promise(resolve=>setTimeout(resolve,4000))
   ]);
  }

  const unavailable=
   $('document').querySelectorAll('.image-missing').length+
   [...$('document').querySelectorAll('img')]
    .filter(img=>!img.complete||!img.naturalWidth).length;

  if(unavailable){
   tell(
    '불러오지 못한 이미지가 '+unavailable+
    '개 있습니다. 이미지 연결을 확인한 뒤 '+
    '다시 PDF 저장을 누르세요.'
   );

   return;
  }

  const details=[
   ...$('document').querySelectorAll('details')
  ];

  const states=details.map(d=>d.open);
  details.forEach(d=>d.open=true);

  try{
   await new Promise(resolve=>
    requestAnimationFrame(()=>
     requestAnimationFrame(resolve)
    )
   );

   if(window.noctDesktop?.savePdf){
    const result=await window.noctDesktop.savePdf(current.file.name);
    if(result?.saved){
     tell('PDF 저장 완료: '+result.path);
    }else if(result?.canceled){
     tell('PDF 저장을 취소했습니다.');
    }else{
     throw new Error(result?.error||'PDF 생성 실패');
    }
   }else{
    window.print();
    tell('인쇄 창에서 “PDF로 저장”을 선택하세요.');
   }

  }finally{
   details.forEach((d,i)=>d.open=states[i]);
  }

 }catch(error){
  tell('PDF를 저장하지 못했습니다: '+(error?.message||'다시 시도해 주세요.'));

 }finally{
  $('pdf').disabled=false;
 }
}

$('openFile').onclick=()=>$('fileInput').click();
$('openFolder').onclick=()=>$('folderInput').click();

$('welcomeOpen').onclick=$('openFile').onclick;
$('welcomeFolder').onclick=$('openFolder').onclick;

for(const id of ['fileInput','folderInput']){
 $(id).onchange=async e=>{
  await importFiles(e.target.files);
  e.target.value='';
 };
}

document.querySelectorAll('button[data-view]').forEach(b=>{
 b.onclick=()=>showView(b.dataset.view);
});

$('pdf').onclick=exportPDF;

$('download').onclick=()=>{
 if(!current)return;

 const url=URL.createObjectURL(current.file);
 const a=document.createElement('a');

 a.href=url;
 a.download=current.file.name;
 a.click();

 setTimeout(()=>URL.revokeObjectURL(url),10000);
};

$('copySource').onclick=()=>{
 copyText(raw,$('copySource'));
};

$('encoding').onchange=()=>{
 if(current)openDocument(current.key);
};

$('smaller').onclick=()=>changeFont(-1);
$('larger').onclick=()=>changeFont(1);

function changeFont(n){
 font=Math.min(26,Math.max(13,font+n));

 document.documentElement.style.setProperty(
  '--size',font+'px'
 );

 $('fontSize').textContent=font;
}

$('wide').onclick=()=>{
 const state=document.body.classList.toggle('wide');
 $('wide').classList.toggle('active',state);
};

$('focus').onclick=()=>{
 const state=document.body.classList.toggle('focus');
 $('focus').classList.toggle('active',state);
};

$('theme').onclick=()=>{
 const light=document.body.classList.toggle('light');
 $('theme').textContent=light?'어둡게':'밝게';
};

$('searchToggle').onclick=()=>{
 toggleSearch($('searchbar').hidden);
};

$('closeSearch').onclick=()=>{
 toggleSearch(false);
};

$('query').oninput=()=>{
 clearTimeout(searchTimer);
 searchTimer=setTimeout(search,180);
};

$('query').onkeydown=e=>{
 if(e.key==='Enter'){
  e.preventDefault();
  moveMatch(e.shiftKey?-1:1);
 }

 if(e.key==='Escape'){
  toggleSearch(false);
 }
};

$('nextMatch').onclick=()=>moveMatch(1);
$('prevMatch').onclick=()=>moveMatch(-1);

$('closeImage').onclick=()=>{
 $('lightbox').close();
};

$('lightbox').onclick=e=>{
 if(e.target===$('lightbox')){
  $('lightbox').close();
 }
};

$('lightbox').addEventListener('close',()=>{
 $('largeImage').removeAttribute('src');
});

document.addEventListener('keydown',e=>{
 if(e.ctrlKey||e.metaKey){
  const key=e.key.toLowerCase();

  if(key==='o'){
   e.preventDefault();
   $('fileInput').click();
  }

  if(key==='k'){
   e.preventDefault();
   toggleSearch(true);
  }

  if(key==='p'&&current){
   e.preventDefault();
   exportPDF();
  }
 }
});

document.addEventListener('dragenter',e=>{
 if(!Array.from(e.dataTransfer.types).includes('Files')){
  return;
 }

 e.preventDefault();
 dragCount++;

 document.body.classList.add('drag');
});

document.addEventListener('dragover',e=>{
 e.preventDefault();
 e.dataTransfer.dropEffect='copy';
});

document.addEventListener('dragleave',()=>{
 dragCount=Math.max(0,dragCount-1);

 if(!dragCount){
  document.body.classList.remove('drag');
 }
});

document.addEventListener('drop',e=>{
 e.preventDefault();

 dragCount=0;
 document.body.classList.remove('drag');

 importFiles(e.dataTransfer.files);
});

window.addEventListener('blur',()=>{
 dragCount=0;
 document.body.classList.remove('drag');
});

window.addEventListener('beforeunload',()=>{
 for(const url of objectURLs.values()){
  URL.revokeObjectURL(url);
 }
});

if(window.marked&&window.DOMPurify){
 installMath();

 tell(
  '파일을 놓거나 폴더를 여세요. '+
  '· Ctrl+O 파일 열기 · Ctrl+K 검색'
 );

}else{
 tell(
  '라이브러리를 불러오지 못했습니다. '+
  '인터넷 연결 후 새로고침해 주세요.'
 );
}

});
