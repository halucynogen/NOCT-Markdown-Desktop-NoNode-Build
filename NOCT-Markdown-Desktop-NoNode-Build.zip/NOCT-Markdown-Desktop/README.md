# NOCT Markdown Viewer — Windows 데스크톱 프로젝트

업로드된 `md_viewer.html`을 Electron 데스크톱 앱으로 변환한 **빌드 가능한 소스 프로젝트**입니다.

> **Node.js를 PC에 설치하고 싶지 않다면:** 방법은 두 가지입니다. (1) **`build-no-install-node.bat`**를 더블클릭하면 임시 Node.js ZIP을 자동으로 받아 빌드하고 삭제합니다(설치 불필요). (2) **[BUILD_WITHOUT_NODE_KO.md](BUILD_WITHOUT_NODE_KO.md)**의 GitHub Actions 방식은 Node.js가 **사용자 PC에서 아예 실행되지도 않습니다.** 완성된 설치형/포터블 EXE의 실행에는 어떤 방식이든 Node.js가 필요 없습니다.

- 기존 디자인: 다크/라이트 테마, 나란히 보기, 검색, 목차, 이미지 확대, 코드 복사, 폴더 열기, 문서 간 상대 링크
- Windows 앱으로 독립 실행: **설치형 EXE + 포터블 EXE**
- **오프라인 실행**: 마크다운 엔진(marked), HTML 정화(DOMPurify), KaTeX 스크립트·스타일·폰트는 빌드시 전부 앱 안에 복사됩니다.
- **온라인 기능 유지**: `https://` 또는 `http://` 이미지 주소를 문서 안에 표시하고 외부 웹사이트 및 온라인 PDF·ZIP·기타 파일 링크는 기본 브라우저로 엽니다.
- **PDF 저장 개선**: Windows 저장 위치 대화상자를 표시하고 직접 PDF 파일로 생성합니다.

## 1. Windows PC에 Node.js를 설치하는 직접 빌드 방법 (선택 사항)

필요한 것:

1. **Windows 10/11 64비트** PC
2. **Node.js LTS (npm 포함)** — https://nodejs.org/
3. **인터넷 연결 (처음 빌드할 때만)** — Electron과 라이브러리 다운로드에 필요

사용 방법:

1. 이 ZIP 파일 압축을 풉니다.
2. 압축을 푼 폴더의 `build-windows.bat`를 더블클릭합니다.
3. 명령 창에서 빌드가 성공하면 `dist` 폴더가 열립니다.
4. 아래 **두 EXE**가 만들어집니다.

| 종류 | 결과 파일명 |
| --- | --- |
| 설치형 | `NOCT-Markdown-Viewer-Setup-1.0.0-x64.exe` |
| 포터블 | `NOCT-Markdown-Viewer-Portable-1.0.0-x64.exe` |

> **중요:** ZIP 자체에는 Windows용 EXE가 들어 있지 않습니다. 이 프로젝트를 Windows에서 빌드해야 EXE가 생성됩니다. 빌드 도구 설치·다운로드는 인터넷이 필요하지만 **완성된 EXE 사용 시 인터넷은 필수가 아닙니다.** 원격 이미지는 당연히 인터넷에 연결된 경우에만 나타납니다.
>
> Windows에서 인터넷에서 받은 서명되지 않은 EXE를 실행할 경우 SmartScreen 경고가 나올 수 있습니다. 상용 배포 시 코드 서명을 권장합니다.

## 2. 명령어로 빌드하기

PowerShell 또는 명령 프롬프트에서 프로젝트 폴더로 이동 후:

```powershell
npm install
npm run build:win
```

종류별로 따로 만들 수도 있습니다.

```powershell
npm run build:portable   # 포터블 EXE만
npm run build:installer  # 설치형 EXE만
npm start                # 개발 중 미리보기
npm run verify           # JavaScript 구문 검사
```

빌드에 사용하는 electron-builder의 `nsis` / `portable` 타깃은 각자 **완전한 독립 실행 프로그램**을 만듭니다. `nsis-web`(인터넷 다운로드형 설치기)은 쓰지 않습니다.

## 3. 오프라인 기능과 온라인 기능

| 기능 | 인터넷 없이 사용 | 설명 |
| --- | --- | --- |
| 마크다운 미리보기 | 예 | marked를 앱 내부에 포함 |
| 수식 표시 | 예 | KaTeX와 폰트를 앱 내부에 포함 |
| 문서 파일 / 폴더 열기 | 예 | 파일 선택 또는 드래그 앤 드롭 |
| 로컬 상대경로 이미지 | 예 | **문서가 포함된 폴더를 함께 열어야 함** |
| 문서 내부/로컬 MD 링크 | 예 | 열린 폴더 안의 MD 파일 간 이동 |
| 찾기, 목차, 글자 크기, 테마 | 예 | 기존 기능 유지 |
| PDF 저장 | 예 | 저장 위치를 직접 선택 |
| 원격 `https://` 이미지 | 아니요 | 인터넷 연결 시 표시, 차단된 URL은 누락 안내 |
| 원격 PDF·ZIP 파일 등 링크 | 아니요 | 기본 브라우저로 주소 전달, 다운로드는 브라우저에 따름 |
| 웹사이트/메일 링크 | 아니요 | 기본 브라우저/메일 앱으로 전송 |

예제 파일: `examples/기능-테스트.md` 및 `examples/다음-문서.md`.

### 마크다운 예시

```markdown
![오프라인 이미지](images/figure.png)
![온라인 이미지](https://example.com/figure.png)
[온라인 PDF 링크](https://example.com/guide.pdf)
[온라인 ZIP 링크](https://example.com/archive.zip)
[열린 폴더의 다른 MD 문서](notes.md)
```

**사용 시 참고:** 온라인 이미지가 있는 문서를 오프라인에서 열 경우 미리보기에서 해당 이미지를 가져올 수 없으며, 기존 뷰어의 안전장치에 따라 이미지 누락 상태에서 PDF 저장이 제한될 수 있습니다. 원격 서버에서 인증·접근 제한·차단을 하는 URL은 인터넷이 있어도 불러오지 못할 수 있습니다.

## 4. 구조

```text
NOCT-Markdown-Desktop/
  .github/workflows/      # GitHub 서버에서 빌드 (PC에 Node.js 불필요)
  BUILD_WITHOUT_NODE_KO.md # Node.js 없는 방법 안내
  build-no-install-node.bat # Node.js 설치 없이, 임시 도구로 빌드
  build-windows.bat       # Node.js 설치 시 로컬 직접 빌드
  package.json            # Electron, 빌드 설정 (x64, NSIS + Portable)
  README.md
  app/
    index.html            # 원본 뷰어 HTML과 레이아웃
    styles.css            # 원본 스타일
    viewer.js             # 원본 기능 + 데스크톱 연동
    main.js               # 창, 외부 링크, PDF 저장
    preload.js            # 허용된 IPC만 제공
    icon.png
    vendor/                # 빌드 시 생성되는 오프라인 라이브러리
  scripts/
    copy-vendor.js        # npm에서 라이브러리/폰트 복사
  build/
    icon.ico              # Windows 아이콘
  examples/               # 오프라인/온라인 샘플
  dist/                   # 빌드 후 EXE 출력 폴더
```

## 5. 보안 및 개인정보

- 마크다운 본문은 기본적으로 로컬 PC에서 처리하며 외부 서버로 업로드하지 않습니다.
- 온라인 이미지 주소를 포함한 MD는 **이미지를 가져오기 위해 해당 외부 서버에 요청**합니다. 온라인 링크 클릭 시 외부 브라우저로 열립니다.
- 외부 링크는 `http:`, `https:`, `mailto:`만 기본 브라우저로 전달합니다.
- `nodeIntegration: false`, `contextIsolation: true`, `sandbox: true`, CSP와 DOMPurify를 적용합니다.
- 임의의 `file://`, `javascript:` 링크를 통해 로컬 시스템 파일을 열거나 스크립트를 실행하지 않습니다.
- 자동 업데이트, 분석·추적, 문서 자동 업로드 기능은 포함하지 않았습니다.

## 6. 사용 라이브러리

| 패키지 | 버전 | 용도 |
| --- | --- | --- |
| Electron | 45.2.3 | Windows 데스크톱 앱 |
| electron-builder | 26.18.1 | 설치/포터블 패키지 |
| marked | 18.1.2 | 마크다운 렌더링 |
| DOMPurify | 3.4.17 | HTML 정화 |
| KaTeX | 0.19.1 | 수식 및 글꼴 |

각 공개 라이브러리의 라이선스 조건이 별도로 적용됩니다. 앱에 포함되는 오픈소스 코드는 원 제작자의 저작권과 라이선스를 존중해야 합니다.
