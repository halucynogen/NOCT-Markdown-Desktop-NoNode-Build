'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const html = read('app/index.html');
const viewer = read('app/viewer.js');
const main = read('app/main.js');
const vendor = read('scripts/copy-vendor.js');
const pkg = require('../package.json');

assert.doesNotMatch(html, /<script[^>]+https?:\/\//i, 'Scripts must not use a CDN');
assert.doesNotMatch(html, /<link[^>]+https?:\/\//i, 'CSS must not use a CDN');
for (const resource of [
  './vendor/marked.umd.js', './vendor/purify.min.js',
  './vendor/katex.min.js', './vendor/katex.min.css', './styles.css', './viewer.js'
]) assert(html.includes(resource), `Missing reference: ${resource}`);

assert(html.includes("img-src 'self' data: blob: https: http:"), 'Remote images must remain allowed');
assert(viewer.includes('if(!url&&/^https?:'), 'Renderer must support remote image URLs');
assert.match(viewer, /noctDesktop\.openExternal\(href\)/, 'External PDF and web links must open in the OS');
assert.match(viewer, /noctDesktop\.savePdf\(current\.file\.name\)/, 'Native PDF save must be present');
assert.match(main, /\['http:', 'https:', 'mailto:'\]/, 'Only safe URL schemes should open externally');
assert.match(main, /printToPDF/, 'PDF export must run in the main process');
assert.match(vendor, /copyDir\('katex\/dist\/fonts', 'fonts'\)/, 'KaTeX fonts must be bundled');
assert.deepEqual(pkg.build.win.target.map(t => t.target), ['nsis', 'portable']);
assert(fs.existsSync(path.join(root, 'build/icon.ico')));
assert(fs.existsSync(path.join(root, 'examples/기능-테스트.md')));

console.log('PASS: HTML/CSS 로컬 번들, 온라인 이미지와 파일 링크, PDF, Windows 2종 빌드 설정');
