'use strict';

// After npm install, copy browser-ready assets into app/vendor.
// Electron will package these resources so the EXEs work with no Internet.
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const dest = path.join(root, 'app', 'vendor');

function copy(source, target) {
  const from = path.join(root, 'node_modules', source);
  const to = path.join(dest, target);
  if (!fs.existsSync(from)) throw new Error(`필수 라이브러리를 찾을 수 없습니다: ${from}\n먼저 npm install을 실행하세요.`);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
  console.log(`+ ${target}`);
}

function copyDir(source, target) {
  const from = path.join(root, 'node_modules', source);
  const to = path.join(dest, target);
  if (!fs.existsSync(from)) throw new Error(`폰트 디렉터리를 찾을 수 없습니다: ${from}`);
  fs.cpSync(from, to, { recursive: true, force: true });
  console.log(`+ ${target}/`);
}

fs.mkdirSync(dest, { recursive: true });
copy('marked/lib/marked.umd.js', 'marked.umd.js');
copy('dompurify/dist/purify.min.js', 'purify.min.js');
copy('katex/dist/katex.min.js', 'katex.min.js');
copy('katex/dist/katex.min.css', 'katex.min.css');
copyDir('katex/dist/fonts', 'fonts');
// Include license notices for the libraries copied into the packaged app.
for (const [packageName, candidates] of [
  ['marked', ['LICENSE.md', 'LICENSE']],
  ['dompurify', ['LICENSE', 'LICENSE.md']],
  ['katex', ['LICENSE', 'LICENSE.md']]
]) {
  for (const filename of candidates) {
    const from = path.join(root, 'node_modules', packageName, filename);
    if (fs.existsSync(from)) {
      fs.copyFileSync(from, path.join(dest, `LICENSE-${packageName}.txt`));
      console.log(`+ LICENSE-${packageName}.txt`);
      break;
    }
  }
}
console.log('오프라인 리소스 준비 완료.');
