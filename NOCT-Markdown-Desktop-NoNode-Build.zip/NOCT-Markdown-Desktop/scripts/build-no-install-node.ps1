# For Windows 10/11 PowerShell 5.1+.
# Downloads the official standalone Node.js ZIP to a temporary folder, runs
# electron-builder and removes the downloaded Node.js folder. Nothing is
# registered as an installed program. Electron apps produced are self-contained.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$projectRoot = Split-Path -Parent $PSScriptRoot
$version = '22.16.0'
$folderName = "node-v$version-win-x64"
$nodeZip = "$folderName.zip"
$downloadUrl = "https://nodejs.org/dist/v$version/$nodeZip"
$tempFolder = Join-Path $env:TEMP ("NOCT-BuildNode-" + [Guid]::NewGuid().ToString('N'))
$archivePath = Join-Path $tempFolder $nodeZip
$nodeFolder = Join-Path $tempFolder $folderName
$oldPath = $env:PATH

Write-Host '1/4 Downloading portable build tools (not installing Node.js)...'
try {
    New-Item -ItemType Directory -Path $tempFolder -Force | Out-Null
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $downloadUrl -OutFile $archivePath -UseBasicParsing
    Expand-Archive -LiteralPath $archivePath -DestinationPath $tempFolder -Force

    $npm = Join-Path $nodeFolder 'npm.cmd'
    if (-not (Test-Path $npm)) {
        throw "Node.js portable ZIP was not extracted correctly: $npm"
    }

    $env:PATH = "$nodeFolder;$oldPath"
    Push-Location $projectRoot
    try {
        Write-Host '2/4 Downloading required app libraries...'
        & $npm install --no-audit --no-fund
        if ($LASTEXITCODE -ne 0) { throw "npm install failed (exit code $LASTEXITCODE)" }

        Write-Host '3/4 Checking application source...'
        & $npm run verify
        if ($LASTEXITCODE -ne 0) { throw "Project verification failed (exit code $LASTEXITCODE)" }

        Write-Host '4/4 Creating portable and installer EXEs...'
        & $npm run build:win -- --publish never
        if ($LASTEXITCODE -ne 0) { throw "Windows build failed (exit code $LASTEXITCODE)" }
    } finally {
        Pop-Location
    }
} catch {
    Write-Error $_
    exit 1
} finally {
    $env:PATH = $oldPath
    # Removing temporary Node.js does not affect the packaged EXEs.
    Remove-Item -LiteralPath $tempFolder -Recurse -Force -ErrorAction SilentlyContinue
}

$dist = Join-Path $projectRoot 'dist'
if (-not (Test-Path $dist)) { Write-Error 'dist directory not found'; exit 1 }
Start-Process explorer.exe -ArgumentList ('"' + $dist + '"')
Write-Host "Build complete: $dist"
exit 0
