# Third-party notices

This project builds on the following open-source components. The packages are installed from npm as part of the build and bundled into the final application.

- **Electron** 45.2.3 — MIT — https://github.com/electron/electron
- **electron-builder** 26.18.1 — MIT — https://github.com/electron-userland/electron-builder
- **marked** 18.1.2 — MIT — https://github.com/markedjs/marked
- **DOMPurify** 3.4.17 — Apache-2.0 OR MPL-2.0 — https://github.com/cure53/DOMPurify
- **KaTeX** 0.19.1 — MIT — https://github.com/KaTeX/KaTeX

Refer to each installed package for the full license text and notices. The original user-supplied `md_viewer.html` is preserved unmodified in `original/`.
