# Node.js 설치 없이 NOCT Windows EXE 받는 방법

**Windows 컴퓨터에 Node.js / npm / Electron / 개발 도구를 설치하지 않아도 됩니다.**

프로젝트에 포함된 `.github/workflows/build-windows.yml`을 이용하면 GitHub의 Windows 서버가 두 가지 EXE를 빌드하고 다운로드용 ZIP으로 제공합니다. 즉, Node.js는 **GitHub 서버에서만** 사용됩니다.

> 이 다운로드 ZIP은 **아직 EXE가 아니라 소스 프로젝트**입니다. GitHub에서 한 번 빌드한 뒤 나온 EXE를 사용하세요.

## 더 간단한 대안: 배치 파일 더블클릭 (Node.js 설치 없음)

GitHub 계정을 사용하고 싶지 않다면 압축을 해제한 폴더 안에서 **`build-no-install-node.bat`**를 더블클릭하세요. 이 방법은 Windows PC에 Node.js를 **설치하지는 않지만**, **공식 Node.js 포터블 ZIP을 임시로 내려받아 빌드 중 사용하고 나서 삭제**합니다. 빌드 중에는 인터넷 연결이 필요하고, 완성된 두 EXE의 실행에는 Node.js가 필요하지 않습니다.

반대로 **PC에서 Node.js를 다운로드하거나 실행하는 것 자체를 원치 않는다면**, 아래 GitHub 서버 빌드 방법을 사용하세요.

## 1. GitHub에서 자동 빌드 시작하기

1. [github.com](https://github.com/)에 로그인합니다. 계정이 없다면 하나 만들어 주세요.
2. 오른쪽 위 **+ → New repository**를 클릭하여 새 저장소를 만듭니다. 저장소명 예: `noct-markdown-desktop`. 원하는 경우 **Private**을 선택해도 됩니다.
3. 이번 프로젝트 ZIP을 PC에서 압축 해제합니다.
4. 새 저장소에서 **uploading an existing file**(또는 **Add file → Upload files**)을 클릭합니다.
5. 압축을 푼 `NOCT-Markdown-Desktop` 폴더 **안의 모든 파일 및 폴더**를 업로드합니다. **`.github/workflows/build-windows.yml`도 반드시 포함**해야 합니다. 파일 하나하나를 루트에 옮기지 말고 폴더 구조를 유지하세요.
6. 아래 **Commit changes**를 누릅니다.
7. 저장소의 **Actions** 탭 → **NOCT Windows EXE (No Node.js on your PC)** → 실행 목록에서 완료된 작업을 선택합니다. 자동 작업이 나타나지 않는다면 **Run workflow**를 눌러 실행합니다. GitHub에서 Actions 사용 승인을 요구할 수 있습니다.
8. 작업이 성공하면 하단 **Artifacts → NOCT-Windows-EXE**를 클릭하여 ZIP을 다운로드합니다.
9. 다운로드한 ZIP을 압축 해제하면 다음 두 파일이 있습니다.
   - `NOCT-Markdown-Viewer-Setup-1.0.0-x64.exe` — 더블클릭해서 일반 Windows 프로그램처럼 설치
   - `NOCT-Markdown-Viewer-Portable-1.0.0-x64.exe` — 설치 없이 바로 실행

## 2. 설치형과 포터블 중 선택

- **설치형**은 시작 메뉴와 바탕화면 바로가기를 만드는 일반적인 Windows 설치 프로그램입니다.
- **포터블**은 하나의 실행 파일을 USB나 다운로드 폴더에 두고 실행합니다.
- **둘 다 사용 시 Node.js가 필요하지 않습니다.** 프로그램 동작에 필요한 Electron 및 오프라인 마크다운 라이브러리가 빌드 결과물에 포함됩니다.

## 3. 인터넷 연결에 대해

- EXE를 GitHub에서 빌드·다운로드할 때 인터넷이 필요합니다.
- 완성된 프로그램을 실행하고 **로컬 MD 파일을 보거나 PDF로 저장하는 데에는 인터넷이 필요하지 않습니다.**
- MD 문서 안의 **온라인 이미지**는 인터넷 연결 시 뷰어 안에 표시됩니다.
- 온라인 PDF·ZIP 등 **외부 파일 링크**는 기본 웹 브라우저로 열립니다.

## 4. 주의사항

- GitHub 계정과 GitHub Actions 빌드 기능이 필요하며, Actions의 무료 제공 범위 및 사용 제한은 GitHub 계정/플랜에 따라 다릅니다.
- 이 프로젝트의 EXE는 코드 서명되어 있지 않아 Windows SmartScreen 경고가 나타날 수 있습니다. 신뢰할 수 있는 직접 빌드 파일만 실행하세요.
- GitHub Actions 빌드는 네트워크 환경과 패키지 배포 상태에 영향을 받을 수 있습니다. **이 환경에서는 실제 Windows 빌드를 완료해 검증하지 못했습니다.**
- 위 가이드의 EXE 이름은 설정상의 **예상 결과 파일명**입니다.

더 자세한 개발/로컬 빌드 안내는 `README.md`를 참고하세요.
